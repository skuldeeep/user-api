


## Setup data base 

find "users.sql" file frm db folder

First you need to import sql file "users.sql" in to phpmyadmin

Please find doc file for more details 


## db config file path 
 user-api\app\config\config.js

## Project setup
```
npm install
```

### Run
```
node server.js
```



## CRon Job setup

Create the cronjob:

>crontab -e

This opens a text file.

Press i to go to insert mode.

Add the following line:

// Cron job will work on server you need to set server path insted of local path

0 0 * * * curl -s "http://localhost:8080/api/cronjob" > /dev/null 