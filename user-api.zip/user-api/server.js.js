const express = require("express");

var env = require('dotenv').config();
var exphbs = require('express-handlebars');

const cors = require("cors");

const app = express();

var corsOptions = {
  origin: "*"
};

app.use(cors(corsOptions));

app.use(express.urlencoded({
  extended: true
})
);
app.use(express.json());

//For Handlebars 
app.set('views', './app/views');
app.engine('hbs', exphbs.engine({
  extname: '.hbs',
  defaultLayout: false,
  layoutsDir: "views/layouts/"
}));
app.set('view engine', '.hbs');
app.get('/', function(req, res) {
  res.send('Welcome to with Sequelize');
});

// parse requests of content-type - application/json
app.use(express.json()); /* bodyParser.json() is deprecated */

// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true })); /* bodyParser.urlencoded() is deprecated */

//Models 
var models = require("./app/models");


//Routes 
require('./app/routes/apiAuth.js')(app);

//Sync Database 
models.sequelize.sync().then(function() {
  console.log('Nice! Database looks fine');
}).catch(function(err) {
  console.log(err, "Something went wrong with the Database Update!");
});





// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to business application." });
});

// set port, listen for requests
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
