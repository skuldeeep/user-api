var express = require('express');
var usersController = require("../controllers/usersController.js");
var router = express.Router();


module.exports = function(app, passport) {
    router.get('/users',  usersController.findAll);
    router.get('/users/:id',  usersController.findById);
    router.post('/users',  usersController.createUser);
    router.put('/users/:id',  usersController.updateUser);
    router.delete('/users/:id',  usersController.deleteUser);

    router.get('/cronjob',  usersController.cronjob);
  


app.use('/api', router);
};