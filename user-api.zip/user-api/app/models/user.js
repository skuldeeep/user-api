module.exports = function(sequelize, Sequelize) {
    var User = sequelize.define('user', {
        id: {
            autoIncrement: true,
            primaryKey: true,
            type: Sequelize.INTEGER
        },
        name: {
            type: Sequelize.STRING,
            allowNull: false,
            validate: {
                notEmpty: {
                    msg: 'Name is required*',
                },
            },
        },
        email: {
            type: Sequelize.STRING,
            allowNull: false,
            validate: {
              isEmail: {
                msg: 'Invalid email format*',
              },
              isUnique: async function (value) {
                const existingUser = await User.findOne({ where: { email: value } });
                if (existingUser) {
                  throw new Error('Email address is already in use*');
                }
              },
            },
        },
   
        createdAt: {
            field: 'created_at',
            type: Sequelize.DATE,
        },
        updatedAt: {
            field: 'modified_at',
            type: Sequelize.DATE,
        }
    });
    return User;
}