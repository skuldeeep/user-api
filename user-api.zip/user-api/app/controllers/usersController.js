const db = require("../models");
var sequelize = require('sequelize');
const Op = sequelize.Op;

module.exports =
{


  // function for get all users data

  findAll : async (req, res) => {
    try {
      let users = await db.user.findAll();
      res.send({ 'status': 1, data: users, 'message': ' Data find successfully' });

    }
    catch (error) {
      res.send({ 'status': 0, data: '', 'error': error });
    }
  },
  
  // functions for fetches a single user by ID.

  findById : async (req, res) => {
    try {
      let id = req.params.id;
      let user = await db.user.findByPk(id);

      if (user === null) {
        res.send({ 'status': 0, data: [], 'message': ' Data not find by id.' });
      } else {
        res.send({ 'status': 1, data: user, 'message': ' Data find by id successfully' });  
      }
    }
    catch (error) {
      res.send({ 'status': 0, data: '', 'error': error });
    }
  },



   // functions for creates a new user.


   createUser: async (req, res) => {
    try {
      let userData = await db.user.create(req.body);
      res.send({ 'status': 1, data: userData, 'message': 'User created successfully' });
    } catch (error) {
      let vError = '';
      if (error.name == 'SequelizeValidationError') {
        let validationError = {};

        error.errors.forEach(res => {
       
          validationError[res.path] = res.message;
        });
       
        vError = validationError;
      }
      res.send({ 'status': 0, "validations": vError });
    }
  },


  // function for update user row
  updateUser: async (req, res) => {
    try {
      let id = req.params.id;
      let body = req.body;
    
      let user = await db.user.findByPk(id);
      if (user === null) {
        res.send({ 'status': 0, data: [], 'message': ' Data not find by id.' });
      } else {
        let userupdate = await db.user.update(body, {
          where: {
            'id': id
          }
        });
        res.send({ 'status': 1, 'message': ' User updated successfully' });
      }
     

    } catch (error) {
      res.send({ 'status': 0, data: '', 'error': error });
    }
  },


   // function for delete user row
  deleteUser: async (req, res) => {
    try {
      let id = req.params.id;
      let users = await db.user.destroy({
        where: {
          'id': id
        }
      });
      res.send({ 'status': 1, data: users, 'message': 'User deleted successfully' });

    } catch (error) {
      res.send({ 'status': 0, data: '', 'error': error });
    }

  },


   // function for cron job delete old data and display list of today user 

   cronjob: async (req, res) => {
    try {

      const TODAY_START = new Date().setHours(0, 0, 0, 0);
      console.log(TODAY_START);
      const NOW = new Date();

      // code for remove old data
      let oldusers = await db.user.destroy({
        where: {
          created_at: { 
            [Op.lt]: TODAY_START,
          },
        }
      });


      // find today data
      let users = await db.user.findAll({
        where: {
          created_at:{ 
            [Op.gt]: TODAY_START,
            [Op.lt]: NOW
          },
        }
      });

      if (users === null) {
        res.send({ 'status': 0, data: [], 'message': 'Today user data not find.' });
      } else {
        res.send({ 'status': 1, data: users, 'message': 'Today Data find successfully' });  
      }
    } catch (error) {
      res.send({ 'status': 0, data: '', 'error': error });
    }

  },
}